﻿namespace P05BorderControl.Contracts
{
    public interface IIdNumber
    {
        string IdNumber { get; }
    }
}
