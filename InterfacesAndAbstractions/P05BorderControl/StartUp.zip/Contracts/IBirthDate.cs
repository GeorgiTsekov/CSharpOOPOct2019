﻿namespace P05BorderControl.Contracts
{
    public interface IBirthDate
    {
        string BirthDate { get; }
    }
}
