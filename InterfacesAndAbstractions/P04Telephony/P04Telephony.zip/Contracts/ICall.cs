﻿
namespace P04Telephony.Contracts
{
    public interface ICall
    {
        string Call(string phoneNumber);
    }
}
