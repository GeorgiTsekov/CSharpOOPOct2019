﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04Telephony.Contracts
{
    public interface IBrowse
    {
        string Browse(string url);
    }
}
