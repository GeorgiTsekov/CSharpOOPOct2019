﻿
namespace P04Telephony.Exceptions
{
    public class ExceptionMesseges
    {
        public static string InvalidURL = "Invalid URL!";
        public static string InvalidNumber = "Invalid number!";
    }
}
