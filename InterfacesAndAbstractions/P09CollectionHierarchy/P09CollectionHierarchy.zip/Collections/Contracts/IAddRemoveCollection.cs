﻿namespace P09CollectionHierarchy.Collections.Contracts
{
    public interface IAddRemoveCollection : IAddCollection
    {
        string Remove();
    }
}
