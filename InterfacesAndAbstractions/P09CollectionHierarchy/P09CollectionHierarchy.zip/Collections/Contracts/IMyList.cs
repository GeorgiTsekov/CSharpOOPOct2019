﻿namespace P09CollectionHierarchy.Collections.Contracts
{
    public interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
