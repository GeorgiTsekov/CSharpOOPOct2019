﻿namespace P09CollectionHierarchy.Collections.Contracts
{
    using System.Collections.Generic;

    public interface IAddCollection
    {
        int Add(string item);
    }
}
