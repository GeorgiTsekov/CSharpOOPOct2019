﻿using P09CollectionHierarchy.Core;
using System;

namespace P09CollectionHierarchy
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
