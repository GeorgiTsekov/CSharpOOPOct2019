﻿using P08MilitaryElyte.Core;

namespace P08MilitaryElyte
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
