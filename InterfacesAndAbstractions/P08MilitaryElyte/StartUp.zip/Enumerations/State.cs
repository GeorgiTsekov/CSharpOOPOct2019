﻿
namespace P08MilitaryElyte.Enumerations
{
    public enum State
    {
        inProgress,
        Finished
    }
}
