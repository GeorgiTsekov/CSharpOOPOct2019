﻿
namespace P08MilitaryElyte.Enumerations
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
