﻿
namespace P08MilitaryElyte.Contracts
{
    public interface IRepair
    {
        string Name { get; }
        int Houres { get; }
    }
}
