﻿
namespace P08MilitaryElyte.Contracts
{
    public interface IPrivate : ISoldier
    {
        decimal Salary { get; }
    }
}
