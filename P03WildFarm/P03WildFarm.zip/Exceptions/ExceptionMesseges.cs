﻿
namespace P03WildFarm.Exceptions
{
    public static class ExceptionMesseges
    {
        public static string InvalidFoodException = "{0} does not eat {1}!";
        public static string InvalidAnimalType = "Invalid Animal Type!";
        public static string InvalidFoodType = "Invalid Food Type!";
    }
}
