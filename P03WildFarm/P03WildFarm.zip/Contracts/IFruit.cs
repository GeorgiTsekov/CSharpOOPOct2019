﻿
namespace P03WildFarm.Contracts
{
    public interface IFruit : IFood
    {
    }
}
