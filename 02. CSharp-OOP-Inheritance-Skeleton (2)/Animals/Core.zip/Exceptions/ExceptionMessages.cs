﻿namespace Animals.Exceptions
{
    public static class ExceptionMessages
    {
        public const string InvalidInputMessage = "Invalid input!";
    }
}
