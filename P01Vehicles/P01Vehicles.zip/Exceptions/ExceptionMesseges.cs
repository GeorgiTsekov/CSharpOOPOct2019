﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01Vehicles.Exceptions
{
    public class ExceptionMesseges
    {
        public static string NegativeFuelExeption = "Fuel must be a positive number";
        public static string FullTankException = "Cannot fit {0} fuel in the tank";
    }
}
